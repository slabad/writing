﻿<#-----------------------------------------------------------------------------
  Powering Development with PowerShell
  Using PowerShell to interact with the Web

  Author: Robert C. Cain | @ArcaneCode | arcanecode@gmail.com
          http://arcanecode.com
 
  This module is Copyright (c) 2015 Robert C. Cain. All rights reserved.
  The code herein is for demonstration purposes. No warranty or guarentee
  is implied or expressly granted. 
 
  This module may not be reproduced in whole or in part without the express
  written consent of the author. 
 -----------------------------------------------------------------------------#>

#region Reading RSS Feeds

#-----------------------------------------------------------------------------#
# Reading RSS Feeds
#-----------------------------------------------------------------------------#
  
# No Agenda Show podcast
$url = 'http://feed.nashownotes.com/rss.xml' 

# Get the data and select a few properties, then display
Invoke-RestMethod $url |
   Select-Object Title, pubDate, duration  |
   Format-List 

# Get the data again, but put all of it in a variable
$rssData = Invoke-RestMethod $url 

# Show the raw XML
$rssData

# Take the saved data and display
$rssData |
   Select-Object Title, subtitle, pubDate, duration  |
   Format-List 

# See what properties are carried in the feed
$rssData | Get-Member -MemberType Property

#endregion Reading RSS Feeds


#region XML Non Well formed

#-----------------------------------------------------------------------------#
# Working with the XML - Non well formed
#-----------------------------------------------------------------------------#

# Save the rss data as XML 
$xmlFilePath = 'C:\PS\Z2H\NAShow.xml'
($rssData | ConvertTo-Xml).Save($xmlFilePath)
psedit $xmlFilePath

# Read the XML back in
$showsXml = [xml](Get-Content $xmlFilePath)

# Now we'll take each node in the xml and convert to a PS object

# First, create an empty array to hold each object 
$shows = @()

# Next, loop over the XML and convert each XML node to an object
foreach($xmlObject in @($showsXml.Objects.Object))
{
  # Create an empty PowerShell object
  $showObject = New-Object -TypeName PSObject

  # Loop over each object in the xml
  foreach($property in @($xmlObject.Property))
  {
    # Add each property as a member to our PowerShell object
    $showObject | Add-Member -MemberType NoteProperty `
                             -Name       $property.Name `
                             -Value      $property.InnerText
  }

  # Append our new PowerShell show object to the array
  $shows += $showObject
}

# Now we have a collection of object we can work with
# For demo we'll just display each title and subtitle
foreach($s in $shows)
{
  "$($s.title) - $($s.subtitle)"
}

# Could also display to screen using piping
$shows | Select-Object -Property title, subtitle

# Create a new array with just the data we want
$showsClean = $shows | Select-Object -Property title, link, pubDate, subtitle, duration
$showsClean

#endregion XML Non Well formed



#region XML Well Formed

#-----------------------------------------------------------------------------#
# Working with the XML - Well formed
#-----------------------------------------------------------------------------#
# Set the new xml path, then create a new object collection from the rss data
$xmlFilePath = 'C:\PS\Z2H\NAShow2.xml'
$showData = $rssData | Select-Object -Property title, link, pubDate, subtitle, duration

# Manually create a big string that will hold XML. 
# By manually creating it, we have the ability to rename the rss field names
# to what we want.
$xmlOutput = "<Shows>`r`n"
foreach($s in $showData)
{
  $row = @"
  <Show>
    <Title>$($s.title)</Title>
    <Episode>$($s.subtitle)</Episode>
    <Link>$($s.link)</Link>
    <PublicationDate>$($s.pubDate)</PublicationDate>
    <Duration>$($s.duration)</Duration>
  </Show>`r`n
"@
  $xmlOutput += $row
}
# Create the closing tag for the XML
$xmlOutput += "</Shows>`r`n"

# Save the XML to a file
$xmlOutput | Out-File $xmlFilePath 
psedit $xmlFilePath 

# Now that we have a well formed XML file, we can work with it easier
$xmlFilePath = 'C:\PS\Z2H\NAShow2.xml'

# Get the XML file we just wrote
$showsXml = [xml](Get-Content $xmlFilePath)

# Selecting a list of shows using XPath syntax
$showsXml.SelectNodes("//Show")

# Select a single node using XPath style syntax
$showsXml.SelectSingleNode("//Title[1]")

# We can also work with it using Object style syntax
# Return the second show (arrays start with 0) in the XML
$showsXml.Shows.Show[1] | Format-Table 

# Return the same node as a list
$showsXml.Shows.Show[1] | Format-List

# Loop over the collection of shows
foreach($s in $showsXml.SelectNodes("//Show"))
{
  "$($s.title) - $($s.Episode)"
}

# Update a node (in memory) 
$showsXml.Shows.Show[1].Title = 'NA800' 
$showsXml.Shows.Show[1].Episode = 'Powering Development with PowerShell'
$showsXml.Shows.Show[1].Duration = '1:04'
$showsXml.Shows.Show[1].PublicationDate = '2015-10-09'
$showsXml.Shows.Show[1].Link = 'http://arcanecode.com/'
$showsXml.Shows.Show[1] 

# Now save the file and display it
$xmlFilePath = 'C:\PS\Z2H\NAShow3.xml'
$showsXML.Save($xmlFilePath)
psedit $xmlFilePath

#endregion XML Well Formed




#region json

#-----------------------------------------------------------------------------#
# Working with JSON
#-----------------------------------------------------------------------------#

# Now take our cleaned up array of object from earlier and convert to json
$jsonData = $showsClean | ConvertTo-Json
$jsonData 

# Save the file
$jsonFilePath = 'C:\PS\Z2H\NoAgenda.json'
Set-Content $jsonFilePath $jsonData
psedit $jsonFilePath

# Read the JSON data back in
$jsonContents = Get-Content -Raw -Path $jsonFilePath | ConvertFrom-Json

# Display the contents
$jsonContents

# Note intellisense
foreach($j in $jsonContents)
{
  "$($j.title) $($j.subtitle)"
}

#endregion json
