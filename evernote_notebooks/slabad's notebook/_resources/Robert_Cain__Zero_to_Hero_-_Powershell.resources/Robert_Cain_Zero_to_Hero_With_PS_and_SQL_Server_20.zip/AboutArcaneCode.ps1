﻿<#-----------------------------------------------------------------------------
  Robert C. Cain, MVP
  Microsoft MVP SQL Server since 2008
  Sr. Software Solutions Architect, Pragmatic Works
  Technical Contributor, Pluralsight
  Co-Author 4 books
  Speaker, SQL Saturdays, PASS Summit, Code Camps
  @ArcaneCode | rcain@pragmaticworks.com

 
  http://bit.ly/acpwhcps - Free webinar on classes in PowerShell
  http://bit.ly/acpluralsight - My Pluralsight Courses
-----------------------------------------------------------------------------#>
